Experiment 23 - Exception Handling and Error Management in Clojure

Run the .clj file in VS Code using Calva: Load/Evaluate Current File.
The program demonstrates ArithmeticException, NullPointerException,
a custom ex-info exception, ex-message, ex-data, and finally.
